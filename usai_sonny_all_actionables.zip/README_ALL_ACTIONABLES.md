USAI Sonny - All Actionables Package
====================================

This package contains everything to finish the end-to-end setup:

- gh_git_push.sh - one-shot script to create GitHub repo and push code
- terraform_walkthrough.sh - guided Terraform init/plan/apply script
- editorial_ui/EditorialDashboard.jsx - React component for editorial dashboard
- editorial_backend/ - FastAPI editorial API skeleton (endpoints: list/create/approve/reject)
- voice/ - Voice consent template and TTS adapters (Amazon Polly & placeholder voice-clone adapter)
- .github/workflows/post_deploy_smoke.yml - smoke test after CI/CD deploy

Next steps:
1. Run gh_git_push.sh to push the repo to GitHub (requires gh CLI auth).
2. Use terraform_walkthrough.sh to provision infra (ensure terraform/ exists in repo with modules).
3. Deploy editorial_backend as a small service on the cluster or as serverless function.
4. Configure voice/consent, provide signed consent if you want voice cloning enabled.
5. Test end-to-end: merge to main -> GitHub Actions builds and deploys -> smoke test runs -> visit editorial UI.

Security & compliance:
- Do not put secrets in code. Use GitHub Secrets for all tokens (AWS_ACCOUNT_ID, GHA_ROLE_ARN, SNYK_TOKEN, SLACK_WEBHOOK).
- For voice cloning, keep signed consent document and store securely with access logs.
