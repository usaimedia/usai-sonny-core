#!/usr/bin/env bash
set -euo pipefail
# Usage: ./gh_git_push.sh YOUR_GITHUB_ORG YOUR_AWS_ACCOUNT_ID
if [ "$#" -lt 2 ]; then
  echo "Usage: $0 <GITHUB_ORG> <AWS_ACCOUNT_ID>"
  exit 1
fi
GITHUB_ORG="$1"
AWS_ACCOUNT_ID="$2"
REPO="usai-sonny-core"

echo "Initializing git repo and pushing to GitHub..."
git init -b main
git add .
git commit -m "Initial commit: USAI Sonny plug-and-play full"
gh repo create ${GITHUB_ORG}/${REPO} --private --source=. --remote=origin --push
echo "Repo created: https://github.com/${GITHUB_ORG}/${REPO}"
echo "Setting GitHub Secrets placeholders..."
gh secret set AWS_ACCOUNT_ID --body "${AWS_ACCOUNT_ID}" --repo ${GITHUB_ORG}/${REPO}
echo "Done. Open the repo in browser:"
gh repo view ${GITHUB_ORG}/${REPO} --web
