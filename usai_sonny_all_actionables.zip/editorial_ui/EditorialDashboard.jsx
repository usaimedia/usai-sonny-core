import React, { useEffect, useState } from 'react'
import axios from 'axios'

export default function EditorialDashboard() {
  const [packages, setPackages] = useState([])
  const [loading, setLoading] = useState(false)
  const API_BASE = process.env.REACT_APP_API_BASE || 'http://localhost:9000'

  useEffect(() => { fetchPackages() }, [])

  async function fetchPackages() {
    setLoading(true)
    try {
      const res = await axios.get(`${API_BASE}/packages`)
      setPackages(res.data || [])
    } catch (e) {
      console.error(e)
    } finally { setLoading(false) }
  }

  async function approve(pkgId) {
    try {
      await axios.post(`${API_BASE}/packages/${pkgId}/approve`)
      fetchPackages()
    } catch(e) { console.error(e) }
  }

  async function reject(pkgId) {
    try {
      await axios.post(`${API_BASE}/packages/${pkgId}/reject`)
      fetchPackages()
    } catch(e) { console.error(e) }
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">USAI Sonny — Editorial Dashboard</h1>
      {loading && <div>Loading packages...</div>}
      <div className="grid grid-cols-1 gap-4">
        {packages.length === 0 && <div className="p-4 bg-gray-50 rounded">No packages found.</div>}
        {packages.map(pkg => (
          <div key={pkg.package_id} className="p-4 bg-white shadow rounded flex justify-between items-center">
            <div>
              <div className="text-lg font-semibold">{pkg.title || 'Untitled'}</div>
              <div className="text-sm text-gray-500">ID: {pkg.package_id} • Virality: {pkg.virality_score}</div>
              <div className="mt-2 text-sm">{pkg.url}</div>
            </div>
            <div className="flex gap-2">
              <button className="px-3 py-1 bg-green-600 text-white rounded" onClick={() => approve(pkg.package_id)}>Approve</button>
              <button className="px-3 py-1 bg-red-500 text-white rounded" onClick={() => reject(pkg.package_id)}>Reject</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
