import boto3

class PollyAdapter:
    def __init__(self, region_name='us-east-1', aws_access_key_id=None, aws_secret_access_key=None):
        self.client = boto3.client('polly', region_name=region_name,
                                   aws_access_key_id=aws_access_key_id,
                                   aws_secret_access_key=aws_secret_access_key)

    def synthesize(self, text, voice_id='Joanna', output_format='mp3', sample_rate='22050'):
        resp = self.client.synthesize_speech(Text=text, VoiceId=voice_id, OutputFormat=output_format, SampleRate=sample_rate)
        audio = resp['AudioStream'].read()
        return audio
