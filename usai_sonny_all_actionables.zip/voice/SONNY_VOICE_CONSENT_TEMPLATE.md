USAI MEDIA - VOICE & LIKENESS CONSENT TEMPLATE
---------------------------------------------

Subject (Owner): Mr. Sonny Chohan
Date: [DATE]

I, Mr. Sonny Chohan, hereby give USAI Media permission to create and use a synthetic voice likeness and portrait-derived avatar of me for the purposes of the USAI Media project, under the following terms:

1. PURPOSE
   - The synthetic voice and avatar will be used solely for creating AI-hosted news summaries, verified content presentations, and promotional material for USAI Media.
2. SCOPE
   - Allowed uses: live streams, short-form video reels, promotional content, training and internal testing.
   - Disallowed uses: political persuasion, deepfake impersonation for fraudulent purposes, harassment, or pornographic content.
3. DATA & SOURCES
   - Source recordings and photos used for model creation are owned by me and provided voluntarily.
4. REVOCATION
   - I may revoke consent at any time in writing; USAI Media will cease new generation and publish a plan to remove or watermark existing content within 30 days.
5. COMPENSATION
   - [Terms to be filled]
6. SECURITY & RETENTION
   - Models and raw audio will be stored securely and access logged. Retention period: [TBD].
7. GOVERNING LAW
   - This agreement is governed by [Jurisdiction].

Signature: ______________________  Date: __________
