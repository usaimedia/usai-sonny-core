# Placeholder adapter for a commercial voice-clone provider.
# DO NOT use until explicit consent is documented in SONNY_VOICE_CONSENT_TEMPLATE.md
class VoiceCloneAdapter:
    def __init__(self, api_key=None, endpoint=None):
        self.api_key = api_key
        self.endpoint = endpoint

    def synthesize(self, text, voice_profile_id=None, style=None):
        # Example placeholder: make POST to provider with voice profile id and text
        # return binary audio bytes
        raise NotImplementedError("Provide provider-specific implementation and credentials.")
