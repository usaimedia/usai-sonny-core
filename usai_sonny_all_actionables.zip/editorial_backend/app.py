from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import time, uuid

app = FastAPI(title='Editorial API')

PACKAGES = []

class ApproveRequest(BaseModel):
    package_id: str
    editor: str | None = None

@app.get('/packages')
def list_packages():
    return PACKAGES

@app.post('/packages/create')
def create_package(pkg: dict):
    pkg['package_id'] = pkg.get('package_id') or 'pkg_' + uuid.uuid4().hex[:8]
    pkg['created_at'] = time.time()
    pkg['status'] = 'pending'
    PACKAGES.append(pkg)
    return pkg

@app.post('/packages/{pkg_id}/approve')
def approve(pkg_id: str):
    for p in PACKAGES:
        if p['package_id'] == pkg_id:
            p['status'] = 'approved'
            return p
    raise HTTPException(status_code=404, detail='package not found')

@app.post('/packages/{pkg_id}/reject')
def reject(pkg_id: str):
    for p in PACKAGES:
        if p['package_id'] == pkg_id:
            p['status'] = 'rejected'
            return p
    raise HTTPException(status_code=404, detail='package not found')
