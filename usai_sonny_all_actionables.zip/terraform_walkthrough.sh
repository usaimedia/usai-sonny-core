#!/usr/bin/env bash
set -euo pipefail
# Interactive walkthrough for Terraform apply (read before running).
echo "This script will guide you through terraform init -> plan -> apply for the usai-sonny infra."
echo "Make sure you edited terraform/terraform.tfvars with real values (aws_account_id, vpc_id, subnet_ids, github_owner)."
read -p "Continue? (y/N): " yn
if [[ "${yn}" != "y" && "${yn}" != "Y" ]]; then
  echo "Aborted."
  exit 1
fi
cd terraform || (echo "terraform dir missing" && exit 2)
terraform init
terraform validate
echo "Running terraform plan (output to tfplan) ..."
terraform plan -out=tfplan
echo "Inspect tfplan with 'terraform show -json tfplan | less' or 'terraform show tfplan'."
read -p "Apply the plan? (y/N): " apply_yes
if [[ "${apply_yes}" == "y" || "${apply_yes}" == "Y" ]]; then
  terraform apply -auto-approve tfplan
  echo "Terraform apply complete. Run 'terraform output' to see outputs."
else
  echo "Skipping apply. Exiting."
fi
